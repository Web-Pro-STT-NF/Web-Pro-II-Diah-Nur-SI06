<?php

class Pasien {
    public $kode, $nama, $tmp_lahir, $tgl_lahir, $email, $gender;
}

?>